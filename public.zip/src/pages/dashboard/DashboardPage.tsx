import Header from '../../components/Header'
import Sidebar from '../../components/Sidebar'

const DashboardPage = () => {
    return (
        <main className='max-w-screen w-full min-h-screen bg-[#181D26]'>
            <Sidebar />
            <div className='flex flex-col max-w-screen w-full pl-[265px] h-screen'>
                <Header />
                <div className='flex flex-col gap-10 px-6 pb-6 w-full h-full'>
                    <h2 className='text-2xl leading-9 text-white font-noto'>Hello John</h2>
                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d32659000.082941387!2d95.87114585505816!3d-2.267478283407199!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2c4c07d7496404b7%3A0xe37b4de71badf485!2sIndonesia!5e0!3m2!1sid!2sid!4v1748746406430!5m2!1sid!2sid" width="600" loading="lazy" className="w-full h-full rounded-2xl"></iframe>
                </div>
            </div>
            {/*<div className='hero'>
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d32659000.082941387!2d95.87114585505816!3d-2.267478283407199!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2c4c07d7496404b7%3A0xe37b4de71badf485!2sIndonesia!5e0!3m2!1sid!2sid!4v1748746406430!5m2!1sid!2sid" width="600" height="450" loading="lazy" className="maps"></iframe>
            </div> */}
        </main>
    )
}

export default DashboardPage