import React from 'react'

const leaveManagementType = {
}

export default leaveManagementType