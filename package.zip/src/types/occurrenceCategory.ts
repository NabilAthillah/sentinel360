export type OccurrenceCategory = {
    id: string;
    name: string;
    status: string;
}