export type EmployeeDocument = {
    id: string;
    name: string;
    status: string; 
    file_name?: string;
    url?: string
    
}