export type Permission = {
    id: string;
        name: string;
    category: string;
}