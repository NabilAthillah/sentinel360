export type Error = {
    success: boolean;
    message: string;
}