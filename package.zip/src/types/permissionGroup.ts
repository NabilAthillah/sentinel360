export type PermissionGroup = {
    
}