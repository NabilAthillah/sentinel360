export type IncidentType = {
    id: string;
    name: string;
    status: string;
}