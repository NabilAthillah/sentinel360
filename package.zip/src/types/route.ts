export type Route = {
    id: string;
    name: string;
    status: string;
    id_site: string;
    route: string;
    remarks?: string;
}