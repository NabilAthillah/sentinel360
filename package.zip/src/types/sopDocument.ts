export type SopDocument = {
    id: string;
    name: string;
    document:string;
}